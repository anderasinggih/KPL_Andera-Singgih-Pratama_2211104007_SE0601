﻿using System;

namespace MatematikaLibraries
{
    public class Matematika
    {
        public static int FPB(int input1, int input2)
        {
            while (input2 != 0)
            {
                int temp = input2;
                input2 = input1 % input2;
                input1 = temp;
            }
            return input1;
        }

        public static int KPK(int input1, int input2)
        {
            return (input1 * input2) / FPB(input1, input2);
        }

        public static string Turunan(int[] persamaan)
        {
            string hasil = "";
            int derajat = persamaan.Length - 1;

            for (int i = 0; i < persamaan.Length - 1; i++)
            {
                int koef = persamaan[i] * (derajat - i);
                int pangkat = derajat - i - 1;

                if (koef >= 0 && i > 0)
                    hasil += "+";

                if (pangkat == 0)
                    hasil += $"{koef}";
                else if (pangkat == 1)
                    hasil += $"{koef}x";
                else
                    hasil += $"{koef}x^{pangkat}";
            }
            return hasil;
        }

        public static string Integral(int[] persamaan)
        {
            string hasil = "";
            int derajat = persamaan.Length - 1;

            for (int i = 0; i < persamaan.Length; i++)
            {
                int pangkat = derajat - i + 1;
                double koef = (double)persamaan[i] / pangkat;

                if (koef >= 0 && i > 0)
                    hasil += "+";

                if (pangkat == 1)
                    hasil += $"{koef}x";
                else
                    hasil += $"{koef}x^{pangkat}";
            }
            hasil += "+C";
            return hasil;
        }
    }
}
