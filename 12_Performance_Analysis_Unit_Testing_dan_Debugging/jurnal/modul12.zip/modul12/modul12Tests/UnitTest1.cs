﻿using Xunit;

namespace modul12Tests
{
    public class CariNilaiPangkatTests
    {
        [Fact]
        public void TestBEqualsZero() => Assert.Equal(1, CariNilaiPangkat(4, 0));
        [Fact]
        public void TestBNegatif() => Assert.Equal(-1, CariNilaiPangkat(4, -3));

        [Fact]
        public void TestBOverLimit() => Assert.Equal(-2, CariNilaiPangkat(2, 11));

        [Fact]
        public void TestAOverLimit() => Assert.Equal(-2, CariNilaiPangkat(101, 2));

        [Fact]
        public void TestOverflow() => Assert.Equal(-3, CariNilaiPangkat(100, 10));

        [Fact]
        public void TestNormal() => Assert.Equal(8, CariNilaiPangkat(2, 3));

        private int CariNilaiPangkat(int a, int b)
        {
            if (b == 0) return 1;
            if (b < 0) return -1;
            if (b > 10 || a > 100) return -2;

            try
            {
                checked
                {
                    int result = 1;
                    for (int i = 0; i < b; i++)
                        result *= a;
                    return result;
                }
            }
            catch (OverflowException)
            {
                return -3;
            }
        }
    }
}