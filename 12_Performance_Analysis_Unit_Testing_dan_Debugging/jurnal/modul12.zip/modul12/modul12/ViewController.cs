﻿using System;
using AppKit;
using Foundation;

namespace modul12
{
    public partial class ViewController : NSViewController
    {
        public ViewController(IntPtr handle) : base(handle)
        {
        }
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            // Do any additional setup after loading the view.
        }

        public override NSObject RepresentedObject
        {
            get { return base.RepresentedObject; }
            set
            {
                base.RepresentedObject = value;
                // Update the view, if already loaded.
            }
        }

        // IBAction yang dipanggil saat tombol "Hitung" ditekan
        partial void Hitung(NSObject sender)
        {
            try
            {
                int a = int.Parse(inputA.StringValue);
                int b = int.Parse(inputB.StringValue);
                int hasil = CariNilaiPangkat(a, b);
                outputLabel.StringValue = $"Hasil: {hasil}";
            }
            catch
            {
                outputLabel.StringValue = "Input tidak valid";
            }
        }

        // Fungsi untuk menghitung a pangkat b sesuai aturan jurnal
        private int CariNilaiPangkat(int a, int b)
        {
            if (b == 0) return 1;
            if (b < 0) return -1;
            if (b > 10 || a > 100) return -2;

            try
            {
                checked
                {
                    int result = 1;
                    for (int i = 0; i < b; i++)
                    {
                        result *= a;
                    }
                    return result;
                }
            }
            catch (OverflowException)
            {
                return -3;
            }
        }
    }
}