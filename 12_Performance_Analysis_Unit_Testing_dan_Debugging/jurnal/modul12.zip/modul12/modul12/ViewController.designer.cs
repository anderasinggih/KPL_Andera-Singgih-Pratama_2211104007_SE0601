// WARNING
//
// This file has been generated automatically by Visual Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;
using System.CodeDom.Compiler;

namespace modul12
{
	[Register ("ViewController")]
	partial class ViewController
	{
		[Outlet]
		AppKit.NSTextField inputA { get; set; }

		[Outlet]
		AppKit.NSTextField inputB { get; set; }

		[Outlet]
		AppKit.NSTextField outputLabel { get; set; }

		[Action ("Hitung:")]
		partial void Hitung (Foundation.NSObject sender);
		
		void ReleaseDesignerOutlets ()
		{
			if (inputA != null) {
				inputA.Dispose ();
				inputA = null;
			}

			if (inputB != null) {
				inputB.Dispose ();
				inputB = null;
			}

			if (outputLabel != null) {
				outputLabel.Dispose ();
				outputLabel = null;
			}
		}
	}
}
